<?php include('header.php'); ?>
<script>
  var content = null;
  setInterval(function() {
    console.log(22);
    const buffer = $(".buffer");
    const contentContainer = $(".contentContainer");
    if (content != null) {
      content = buffer.children();
      content.each(element => {
        contentContainer.append(element);
      });
    }
    buffer.empty();
    buffer.load("content.php");
    contentContainer.empty();
  }, 1000);
</script>

<div id="betModal" class="modal">
  <div class="modal-content">
    <h2 id="betModalTitle"></h2>
    <p>Válassz összeget:</p>
    <input type="number" id="betAmount" min="1" max="1000">
    <button>Küldés</button>
    <button id="closebtn">&times;</button>
  </div>
</div>
<div class="contentContainer">
  <?php include('content.php'); ?>
</div>
<div class="buffer">
  
</div>

<?php include('footer.php') ?>