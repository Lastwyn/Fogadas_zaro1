<div class="row">
                <footer>
                <p>&copy; 2023 Sőregi Dávid fogadó oldala.</p>
                </footer>
            </div>
        </div>
    
    </body>
</html>