<!DOCTYPE html>
<html lang="hu">

<head>
  <title></title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="kinezet.css?<?php echo time(); ?>" rel="stylesheet">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

</head>

<body>
  <div class="container">
    <div class="row">
      <header>
        <h1>My Betting Site</h1>
        <nav>
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Sports Betting</a></li>
            <li><a href="#">Horse Racing</a></li>
            <li><a href="#">Virtual Sports</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
          </ul>
          <button class="button">Sign Up</button>
        </nav>
      </header>
    </div>