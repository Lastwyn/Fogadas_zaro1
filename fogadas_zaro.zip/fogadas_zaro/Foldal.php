<?php include('header.php'); include('database.php');
$sql2 = "SELECT * FROM meccs_eredmeny ORDER BY meccs_id DESC LIMIT 1;";
$result =  $db->RunSQL($sql2)->fetch_assoc();
print_r($result);

$sql = "SELECT DISTINCT nemzetek.nemzet_nev FROM nemzetek INNER JOIN meccs_eredmeny ON meccs_eredmeny.hazai_id = nemzetek.nemzet_id WHERE nemzetek.nemzet_id = ?";
$hazainev = $db->RunSQLPrms($sql, "i", $result['hazai_id']);

$sql3 = "SELECT DISTINCT nemzetek.nemzet_nev FROM nemzetek INNER JOIN meccs_eredmeny ON meccs_eredmeny.hazai_id = nemzetek.nemzet_id WHERE nemzetek.nemzet_id = ?";
$vendegnev = $db->RunSQLPrms($sql3, "i", $result['vendeg_id']);

?>
<div class="row">
<main>
  <div class="kozos">
 
    <div class="meccsek"> 
    <table class="hazaitable">
      <tr>
        <td><h1>0</h1></td>
        <tr>
        <td><h2><?php print_r($hazainev->fetch_assoc()['nemzet_nev']);?></h2></td>
        </tr>   
      </tr>
    </table>
    <table class="eredmenyektable">
      <tr>
        <td><h1>---</h1></td>
        <tr>
        <td><h2>Eredmények</h2></td>
        </tr>   
      </tr>
    </table>
    <table class="vendegtable">
      <tr>
        <td><h1>0</h1></td>
        <tr>
        <td><h2><?php print_r($vendegnev->fetch_assoc()['nemzet_nev']);?></h2></td>
        </tr>   
      </tr>
    </table>

    </div>
    <div class="meccsek2"> 
    <h1>aaaa</h1> 
    </div>
</div>
</main>

</div>
   
<?php include('footer.php')?>
