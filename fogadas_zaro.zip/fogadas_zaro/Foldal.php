<?php include('header.php'); include('database.php');
$sql2 = "SELECT * FROM meccs_eredmeny ORDER BY meccs_id DESC LIMIT 1;";
$result =  $db->RunSQL($sql2)->fetch_assoc();
$gollovo = explode(",", $result['gol_szerzo']);
$pieces = explode("-",$result['eredmeny']);

$sql = "SELECT DISTINCT nemzetek.nemzet_nev FROM nemzetek INNER JOIN meccs_eredmeny ON meccs_eredmeny.hazai_id = nemzetek.nemzet_id WHERE nemzetek.nemzet_id = ?";
$hazainev = $db->RunSQLPrms($sql, "i", $result['hazai_id']);

$sql3 = "SELECT DISTINCT nemzetek.nemzet_nev FROM nemzetek INNER JOIN meccs_eredmeny ON meccs_eredmeny.hazai_id = nemzetek.nemzet_id WHERE nemzetek.nemzet_id = ?";
$vendegnev = $db->RunSQLPrms($sql3, "i", $result['vendeg_id']);

$sql4 = "SELECT * FROM `jatekosok` WHERE `nemzet_id` = ?";
$jatekosokhazai = $db->RunSQLPrms($sql4, "i", $result['hazai_id']);

$sql5 = "SELECT * FROM `jatekosok` WHERE `nemzet_id` = ?";
$jatekosokvendeg = $db->RunSQLPrms($sql5, "i", $result['vendeg_id']); 
?>
<div class="row">
<main>
  <div class="kozos">
    
 
    <div class="meccsek">
      <div class="grid-container">
        <div class="col1">
          <h1><?php print_r($pieces[0]);?></h1>
          <h2><?php print_r($hazainev->fetch_assoc()['nemzet_nev']);?></h2>
          <h2>Játékosok:</h2>
         
          <?php
        foreach ($jatekosokhazai->fetch_all() as $key => $value) {
            echo "<tr><td><h4>".$value[1]."</h4></td></tr>";
        }?> 

      </div>
        <div class="col2">
          <h1>---</h1>
          <h2>Eredmények</h2>
          <h2>Gólszerzők:</h2>
          <?php
        foreach ($gollovo as $key => $value) {
          echo "<tr class=\"players\"><td><h4>".$value."</h4></td></tr>";
        }?> 
        </div>
        <div class="col3">
          <h1><?php print_r($pieces[1]);?></h1>
          <h2><?php print_r($vendegnev->fetch_assoc()['nemzet_nev']);?></h2>
          <h2>Játékosok:</h2>
          <h4><?php print_r($jatekosokvendeg->fetch_assoc()['jatekos_nev']);?></h4>
          <?php
        foreach ($gollovo as $key) {
          echo "<tr><td><p></p></td></tr>";
        }?> 
        </div>
      </div>

    </div>
    <div class="meccsek2"> 
    <h1>aaaa</h1> 
    </div>
</div>

</main>

</div>
   
<?php include('footer.php')?>
