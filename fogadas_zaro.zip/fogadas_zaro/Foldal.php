<?php include('header.php')?>
<div class="row">
<main>
  <div class="kozos">
 
    <div class="meccsek"> 
    <h1>aaaa</h1>

    </div>
    <div class="meccsek2"> 
    <h1>aaaa</h1> 
    </div>
</div>
</main>

</div>
   
<?php include('footer.php')?>
